# END USER LICENSE AGREEMENT (EULA)

**Product:** UIKit for React Native Web
**Licensor:** Ha Thanh Tam
**Last Updated:** 16 Sep 2026

By purchasing, downloading, installing, or using UIKit for React Native Web (the "Software"), you agree to be bound by the terms of this License Agreement. If you do not agree to these terms, do not purchase, download, or use the Software.

---

### 1. LICENSE GRANT
Subject to your payment of the applicable license fees, the Licensor grants you a non-exclusive, non-transferable, non-sublicensable, revocable license to use the Software solely in accordance with the license type purchased.

*   **Single Developer License:** Valid for use by exactly one (1) developer. You may install and use the Software to build unlimited personal or commercial end-products (such as websites or mobile apps) for yourself or for clients.
*   **Team / Enterprise License:** Valid for use by up to 5 developers within the same organization.

### 2. PERMITTED USES
You are permitted to:
*   Modify, customize, and extend the source code of the Software to integrate it into your own applications or your clients' applications.
*   Distribute the Software *only* when it is bundled, compiled, and integrated into a larger, functional end-product application where the source code of this UI Kit is not easily extractable.

### 3. RESTRICTIONS & PROHIBITED USES
You are strictly prohibited from:
*   Redistributing, selling, leasing, renting, sublicensing, or giving away the original or modified source code of the Software as a standalone asset, UI kit, component library, boilerplate, or template.
*   Including the Software in an open-source project or repository accessible to the public (e.g., public GitHub repositories).
*   Creating a competitive product (such as another UI library or component builder) that directly utilizes or wraps the source code of this Software.

### 4. INTELLECTUAL PROPERTY & OWNERSHIP
The Licensor retains all ownership, rights, title, and intellectual property interest in and to the Software. This agreement does not sell the Software to you; it only licenses it. Third-party dependencies included in this Software remain governed by their respective open-source licenses (as detailed in the accompanying `THIRD-PARTY-LICENSES` file).

### 5. TERMINATION
This license is effective until terminated. Your rights under this license will terminate automatically without notice if you fail to comply with any of its terms. Upon termination, you must cease all use of the Software and destroy all copies of the source code in your possession.

### 6. NO WARRANTY ("AS IS")
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT, OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE.

### 7. LIMITATION OF LIABILITY
IN NO EVENT SHALL THE LICENSOR BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES WHATSOEVER ARISING OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, EVEN IF THE LICENSOR HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
